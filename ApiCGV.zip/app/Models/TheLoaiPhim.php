<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TheLoaiPhim extends Model
{
    use HasFactory;
    protected $fillable = [
        'tenTheLoai',
    ];
    public $timestamps=false;
}
